## Build Layers
nrows = 5
ncols = 5

base = matrix(1, nrow = nrows, ncol = ncols)
recruit = cbind(rep(0.2,5), rep(0,5), rep(0,5), rep(0,5), rep(0,5))
ssb = cbind(rep(0.0,5), rep(0,5), rep(1,5), rep(1,5), rep(1,5))


