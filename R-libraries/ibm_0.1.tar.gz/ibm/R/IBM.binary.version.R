"IBM.binary.version"<-
function() {
return("2018-04-08 08:42:29 UTC (rev. 9e3f478c)")
}
