#' Utility function for summary
#'
#' @author C Marsh
#' This is a utiltiy function that will summarise a derived quantity report for a Casal2MPD class
#'
"mpd_derived_quantity" <-
function(report_list) {
  ## see what type of derived 
  
}
