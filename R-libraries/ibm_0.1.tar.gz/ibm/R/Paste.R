#' Utility plot function
#'
#' @author Craig Marsh
#' @keywords internal
#'
Paste = function(... , sep = "") {paste(..., sep = sep)}


